<?xml version="1.0"?>
<page xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" layout="2columns-left" xsi:noNamespaceSchemaLocation="urn:magento:framework:View/Layout/etc/page_configuration.xsd">
<head>
    <title>Support - Contact</title>
</head>
<body>
    <referenceContainer name="content">
       <block class="Magento\Contact\Block\ContactForm" name="support-form" template="Nethues_CustomContatUs::support-form.phtml" />
               
    </referenceContainer>


</body>
</page>